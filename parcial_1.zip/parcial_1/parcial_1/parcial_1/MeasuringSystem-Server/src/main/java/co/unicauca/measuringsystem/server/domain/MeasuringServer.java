/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicauca.measuringsystem.server.domain;

/**
 *
 * @author ANDRE
 */
public class MeasuringServer {
    private ProductItemMeasuring itemMedicion;

    public MeasuringServer(ProductItemMeasuring itemMedicion) {
        this.itemMedicion = itemMedicion;
    }
    
}
